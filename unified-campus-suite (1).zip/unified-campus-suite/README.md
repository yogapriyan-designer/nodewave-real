# Campus Suite
Open `index.html` (or use VS Code Live Server). Two cards:
- Smart Room System -> smart-room-finder/index.html
- Attendance Intelligence -> attendance-intelligence/index.html
Each app has a "Home" button (bottom-left) to return to this page.
Both apps keep their original folders/READMEs; nothing else was changed.
