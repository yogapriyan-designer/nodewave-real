# Smart Room Finder
Availability computed live from your 10 timetable sheets (no hard-coded status).

## Run
- **Easiest:** open `index.html` in a browser, or in VS Code right-click it → *Open with Live Server*.
- Or: `npx serve .`

## Structure
- `data/data.js` – normalized timetable data (loaded by the page). `data/timetable.normalized.json` – same data as JSON.
- `js/engine.js` – availability engine + rule-based AI parser (replace `parse()` with an LLM call later).
- `js/three-view.js` – 3D rotating building (three.js r147, bundled offline in `js/vendor/`).
- `js/app.js` – UI. `css/styles.css` – styling.
- `tools/build_dataset.py` – the transcribed 10 timetables + validator. Edit it, then `cd tools && python3 build_dataset.py` to regenerate the data.

## Assumptions (change in code / data if wrong)
- Floors are inferred from the room number: 1xx = Ground, 2xx = First … (`floorIdx` in engine.js).
- The 2024-25 sheet (file 10) is excluded from live availability by default (toggle on Data Status page).
- The timetables contain no AC / capacity / facilities data, so requests for those return "cannot verify" + labelled alternatives.
- "Available soon" = occupied but ends within 15 minutes (`SOON_MIN`).
- Use "Simulate time" in the header to demo a weekday (weekends have no classes).

## 3D controls
Drag = rotate 360° · scroll/pinch = zoom · click a room = details · Floor Map page: pick a floor to isolate it · buttons: Auto-rotate / Reset / Top / Front.
Needs a browser with WebGL (any modern Chrome/Edge/Firefox/Safari).
